package com.rajkhare.sbur_rest_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SburRestDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
